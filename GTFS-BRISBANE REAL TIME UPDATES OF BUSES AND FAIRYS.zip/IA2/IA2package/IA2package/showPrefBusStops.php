<?php
require_once('helperFunctions.php');
//Is the user logged in?
if (!empty($_SESSION['username'])) {
    $sqlQuery = "Select stop_id FROM users where username = %s";
    $stops = DB::queryFirstRow($sqlQuery, $_SESSION['username']);
if (DB::affectedRows()== 1) {
    $nominatedStop = $stops['stop_id'];
}
else
{
    $nominatedStop = "A stop has not be set yet";
}
    echo "<span><strong>Prefered Stop:</strong> $nominatedStop</span> ";

    $sqlQuery = "Select busID FROM buses where username = %s";
    $buses= DB::query($sqlQuery, $_SESSION['username']);
    echo "<span><strong>Current prefered buses:</strong></span> ";
    foreach ($buses as $bus)
    {   
        $busID = $bus['busID'];
        echo "<button class='m-2 btn btn-danger'>$busID</button>";
    }

}
else
{
    echo "<h3>Not logged in. No preferences available</h3>";
}