<?php
    require_once "Home.php"
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="dash.css">

</head>
<body>
    <div class="container">
    <div class="panel post">
        <a href="javascript:void();"><span>8 </span>Posts</a>
    </div>
    <div class="panel comment">
        <a href="javascript:void();"><span>39 </span>Comments</a>
    </div>
    <div class="panel page">
        <a href="javascript:void();"><span>5 </span>Pages</a>
    </div>
    <div class="panel user">
        <a href="javascript:void();"><span>4 </span>Users</a>
    </div>
    </div>
</body>
</html>
