//Be sure to declare variables that you want to keep alive and available throughout you functions here
var map;
var sitesLayer;//Add a similar variable for each layer you want to add
var googleTerrain;
var baseTiles;//Add a similar variable for each tileset you are using (ie roads=baseTitles, satelite=satTiles)
var siteMarkers = new Array(); //Add a similar variable for each set of markers you are usings
var sites; //Add a similar variable for each raw dataset you are bringing
var layerControl;//Only one layer control will ever be needed
var modalArea;
var offcanvasArea;
var busLayer = L.layerGroup();
var busMarkers = new Array();
var buses;
var routeLines = [];
var polylines = [];
var ferryPattern = /^(TNR[BFK]|NHA[MQR]|UQS[GLP]|NTH[BCDEFGHJKMNP]|SYD[NEY]|HOL[MES]|THR[NP]|SMB[IJKL]).*$/;
var latitude;






window.onload = (event) => {
    loadMap();//Everything in the load map will be run ONCE the page (window) has loaded.
    modalArea = new bootstrap.Modal(document.getElementById('modalArea'),{ keyboard:true, focus:false});
    offcanvasArea =  new bootstrap.Offcanvas(document.getElementById('offcanvasRight'), { keyboard:true, focus:false});
    }

    function drawRoutes()
    {
        colours = new Array("red", 'green', 'blue', 'yellow', 'orange', 'purple');
        try
        {
            if (routeLines.length > 0)
            {
                for (let counter = 0; counter < routeLines.length; counter++)
                {
                    polylines[counter] = L.polyline(routeLines[counter], {color: colours[counter % colours.length]}).addTo(map);
                }
            }
        }
        catch(error)
        {
            console.log(error);
        }
    }


async function loadMap()
{
    //Use this style to bring in other data sources
    //Be sure to have the variable declared at the "top" globally
    sites = await loadExternalData("https://www.bnefoodtrucks.com.au/api/1/sites");


    //https://gtfsrt.api.translink.com.au/api/realtime/CNS/VehiclePositions

     buses = await loadProtoBuffer("https://gtfsrt.api.translink.com.au/api/realtime/SEQ/VehiclePositions");

     //var singleBus = L.marker([buses[0].vehicle.position.latitude, buses[0].vehicle.position.longitude])

    createBusMarkers();

    //16.9203° S, 145.7710° E

    createBaseTitles();
    map = L.map('map', {
        center: [-27.4698, 153.0251],
        zoom: 10,
        maxzoom:20,
        minzoom:1,
        layers: [baseTiles, busLayer]
    });
    //Be sure to add other layers in addition to the two above ^^^^^^
    createControls();
    // draw the routes
    drawRoutes();
}

async function updateBuses()
{
    buses = await loadProtoBuffer("https://gtfsrt.api.translink.com.au/api/realtime/SEQ/VehiclePositions");
    console.log("Updating Map");
    createBusMarkers();
    map.addLayer(busLayer);  //Add here as createBusMarkers is first run BEFORE the map exists
    setTimeout(updateBuses, 10000);
}



setTimeout(updateBuses, 10000);
function createBusMarkers() {
    busMarkers = new Array();
    busLayer.clearLayers();
    for (let busCounter = 0; busCounter < buses.length; busCounter ++) {
        let lat = buses[busCounter].vehicle.position.latitude;
        let long = buses[busCounter].vehicle.position.longitude;
        let busCode = "<span class='busLabel'> " + buses[busCounter].vehicle.vehicle.label + "</span>";
        let popupText = "<b>Vehicle Label:</b> " + buses[busCounter].vehicle.vehicle.label +
            "<br><b>Route ID:</b> " + buses[busCounter].vehicle.trip.route_id +
            "<br><b>Current Stop Sequence:</b> " + buses[busCounter].vehicle.current_stop_sequence +
            "<br><b>Current Status:</b> " + (buses[busCounter].vehicle.current_status === 1 ? "MOVING" : "STOPPED") +
            "<br><b>Speed:</b> " + buses[busCounter].vehicle.speed + " km/h" +
            "<br><b>Occupancy:</b> " + (buses[busCounter].vehicle.occupancy_status === 0 ? "EMPTY" :
                (buses[busCounter].vehicle.occupancy_status === 1 ? "MANY SEATS" : "STANDING ROOM ONLY"));
        if (ferryPattern.test(buses[busCounter].vehicle.trip.route_id)) {
            busMarkers[busCounter] = L.marker(
                [lat, long], {
                    icon: new L.DivIcon({
                        className: 'ferryIcon',
                        html: busCode,
                        iconSize: [70, 70]
                    }),
                    vehicleType: 'ferry'
                }
            );
        } else {
            busMarkers[busCounter] = L.marker(
                [lat, long], {
                    icon: new L.DivIcon({
                        className: 'busIcon',
                        html: busCode,
                        iconSize: [70, 70]
                    }),
                    vehicleType: 'bus'
                }
            );
        }
        busMarkers[busCounter].bindPopup(popupText);
    }
    busLayer = L.markerClusterGroup().addLayers(busMarkers);
}



function createControls()
{
    //You could add extrabase titles, like satelite, here
    let baseLayers = {
        "Roads & Suburbs":baseTiles,
        "Satelite":googleTerrain,
    };
    //Be sure to add extra layers here using the same style as beloow
    let overlays = {
        "Cairns Buses": busLayer,
    };

    L.control.layers(baseLayers, overlays, {autoZIndex:false, hideSingleBase:true}).addTo(map);
}

function createBaseTitles()
{

    baseTiles = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    });



    googleTerrain = L.tileLayer('http://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}',{
        maxZoom: 20,
        subdomains:['mt0','mt1','mt2','mt3']
    });
    //Add other baseTiles like layers here (satelite for example)
}

function updateRatingNumber(id)
{
    let selectedRating = document.getElementById(`site${id}`).value;
    let numberDisplay = document.getElementById(`site${id}Number`)
    numberDisplay.innerHTML = selectedRating;
    triggerAnimation(numberDisplay, 'text-focus-in .5s 1 linear');
}

//echo "<select id='stopsToShow' onclick='setPreferedStop()'>";


function setPreferedStop(){
    submitData("setPreferedStop", "stopsToShow", "");
}

//Add an addBus function here to set and store the click bus option
async function setBus(busID, buttonID)
{

    var JSONtoSend = {"ajaxPost":{"allData":[{"busID": busID, "buttonID": buttonID}], "action":"setPreferedBus"}};
    response = await postData("ajaxProcessor.php",  JSONtoSend);
    ajaxCallback(response);   
}

function findSuggestedStops(){
    submitData("searchForStop", "textStopSearch", "");
}

function setStopDropDown(dropDownValue) {
    console.log("Setting the stop to" + dropDownValue);
    for (var option of document.getElementById("stopsToShow").options) {
        console.log(option.value);
        if (option.value == dropDownValue) {
            console.log("found it");
            option.selected = true;
            setPrefferedStop();
        }
    }
}

