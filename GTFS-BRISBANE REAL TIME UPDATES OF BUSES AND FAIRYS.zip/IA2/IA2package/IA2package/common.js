class ajaxDataRequest {

    constructor(action) {
        this.action = action;
        this.allData = [];
    }

}

class ajaxTuple {
    constructor(id, field, value) {
        this.id = id;
        this.field = field;
        this.value = value;
    }
}

/*Usage 
if (validateField('site525', 'I', {min:1, max:2}))
{
    console.log('valid')
}
*/

//INPUT -> ID of a field, Single letter to identify what sort of value you want, JSON conditions
//OUTPUT -> JSON version of URL data


function validateField(fieldID, validationType, conditions)
{
    let value = document.querySelector("#" + fieldID).value;
    //Example of validation of an integer
    if (validationType == 'I')
    {
        value = parseInt(value);
        let max = conditions.max;
        let min = conditions.min;
        if (value >= min && value <= max && Number.isInteger(value))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}

/*Usage 
const variableToHoldData = loadProtoBuffer('urlOfData');
*/

//INPUT -> URL 
//OUTPUT -> JSON version of URL data

async function loadProtoBuffer(url)
{
    const myRequest = new Request("proxy.php?" + url + "?q=" + new Date().getTime());
    let rawResult = await fetch(myRequest);
    const bufferRes = await rawResult.arrayBuffer();
    const pbf = await new Pbf(new Uint8Array(bufferRes));
    const obj = await FeedMessage.read(pbf);
    return obj.entity;
}


/*Usage 
const variableToHoldData = loadExternalData('urlOfData');
*/

//INPUT -> URL 
//OUTPUT -> JSON version of URL data

async function loadExternalData(url) {
    const myRequest = new Request("proxy.php?" + url);
    let rawResult = await fetch(myRequest);
    let backupResponse = rawResult.clone();
    try 
    {
        return await rawResult.json();
    }
    catch
    {
        let feedback = await backupResponse.text();
        console.log(feedback);
    }
   
}


/*Usage 
const variableToHoldData = loadProtoBuffer('urlOfData');
*/

//INPUT -> URL to send JSON data to, data to be sent as JSON 
//OUTPUT -> JSON response

async function postData(url = '', data = {}) {
    // Default options are marked with *
    const response = await fetch(url, {
        method: 'POST', // *GET, POST, PUT, DELETE, etc.
        mode: 'cors', // no-cors, *cors, same-origin
        cache: 'no-cache', // *default, no-cache, reload, force-cache, only-if-cached
        credentials: 'same-origin', // include, *same-origin, omit
        headers: {
            'Content-Type': 'application/json'
            // 'Content-Type': 'application/x-www-form-urlencoded',
        },
        redirect: 'follow', // manual, *follow, error
        referrerPolicy: 'no-referrer', // no-referrer, *no-referrer-when-downgrade, origin, origin-when-cross-origin, same-origin, strict-origin, strict-origin-when-cross-origin, unsafe-url
        body: JSON.stringify(data) // body data type must match "Content-Type" header
    });
    return response.json();
}





/*Usage Examples - To send data, converted to JSON, to your ajaxProcessor

Single- tuple
----------------------------
let id = 4534; //Of the field to draw the data from
let field  = 'site'; //fields name prefix, can be empty
let action = 'addRating';
submitData(action, field, id);

Multi-tuple
----------------------------
submitData('deleteSites', site, '1', site, '2');



INPUT -> action, and single or multiple 
OUTPUT -> JSON version of URL data

..arg are made up of an input field prefex (like rating) and the unique id of that field. You can include many args to send extra data.
*/


async function submitData(action, ...args) {
    dataToSend = new ajaxDataRequest(action);
    let dataCounter = 0;
    for (let counter = 0; counter < args.length; counter += 3) {
        let value = document.querySelector("#" + args[counter] + args[counter + 1]).value;
        let id = args[counter + 1];
        let field = args[counter];
        dataToSend.allData[dataCounter] = new ajaxTuple(id, field, value);
        dataCounter += 1;
    }
   
    let messageToSend = {"ajaxPost": dataToSend};
    console.log("sent to ajaxProcessor.php:" + JSON.stringify(messageToSend));
    let response = await postData(url = 'ajaxProcessor.php', data = messageToSend)
    ajaxCallback(response)
}

function makeList(dataObject, propertyToList) {
    let list = "<ul>";
    for (let counter = 0; counter < dataObject.length; counter++) {
        //sitesData[0]['title']
        list += "<li>";
        list += dataObject[counter][propertyToList];
        list += "</li>";
    }
    list += "</ul>";

    return list;
}


//The response sent back is determined by your ajaxProcessor.php

async function ajaxCallback(response)
{
    console.log("Received from ajaxProcessor.php:" + JSON.stringify(response));
    if (response.callbackID == 1)
    {
        console.log(response.outcome + "\n" +  response.message);
        //Add logic for what to do for this callback here
        //All of "response is available to use in the callback" 
    }
    if (response.callbackID == 2)
    {
        //Not logged in callback
        console.log(response.outcome + "\n" +  response.message);
    }
    if (response.callbackID == 3)
    {
        //No data callback
        console.log(response.outcome + "\n" +  response.message);
    }
    if (response.callbackID == 4)
    {
        //No data callback
        document.getElementById('stopFeedback').innerHTML = response.message;
        triggerAnimation('stopFeedback', "text-focus-in .5s 1 linear");
        console.log(response.outcome + "\n" +  response.message);
    }
    if (response.callbackID == 5)
    {
        //No data callback
        document.getElementById('stopFeedback').innerHTML = response.outcome;
        triggerAnimation('stopFeedback', "text-focus-in .5s 1 linear");
        console.log(response.outcome + "\n" +  response.message);
    }
    if (response.callbackID == 7)
    {
        console.log("callback triggered");
        //No data callback
        let outputArea = document.getElementById('suggestions');
        outputArea.innerHTML = response.message;
    }

}

//Element must be an object (ie grabbed by document.getElementByID())
//Animation must be in the format 'animationName durationAsSeconds numberOfTimesToPlay typeOfPlay'
//For more see https://developer.mozilla.org/en-US/docs/Web/CSS/animation
//To make animations see https://animista.net/
//For example 'text-focus-in .5s 1 linear'

function triggerAnimation(element, animation)
{
    let animationDetails = animation.split(" ");
    currentElement = document.getElementById(element);
    try 
    {

        currentElement.style.animation ='none';
        currentElement.style.animation = animation;
    }
    finally{
        currentElement.offsetWidth; // trigger reflow
        console.log("Animating " + element +  " using " + animationDetails[0] + " class");
    }
}

//Add code to this to run every 5000 milliseconds
function constantCheck()
{
    let d = new Date();
    let time = d.toLocaleString("en-AU");
    console.log(time);
    setTimeout( constantCheck, 5000);
}

constantCheck();