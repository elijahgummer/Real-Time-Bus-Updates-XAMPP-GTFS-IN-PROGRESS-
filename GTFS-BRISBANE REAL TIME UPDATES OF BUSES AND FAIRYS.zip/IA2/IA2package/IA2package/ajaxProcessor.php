<?php
include_once("helperFunctions.php");
// Example data for JSON
//{"ajaxPost":{"allData":[{"id":"525","field":"site","value":"3"}]},"action":"addRating"}

$dataOut = array();

$dataIn = json_decode(file_get_contents('php://input'), true);

if(empty($_SESSION['username']))
{
    $dataOut["outcome"] = "Unauthorised";
    $dataOut["message"]= "Data unavailable";
    $dataOut['callbackID'] = "2";
    echo json_encode($dataOut);
    exit();
}

if (!is_array($dataIn) || $dataIn == false)
{
    $dataOut["outcome"] = "No data submitted";
    $dataOut["message"]= "This request could not be resolved:" . $dataIn;
    $dataOut['callbackID'] = "3";
    echo json_encode($dataOut);
    exit();

}
else
{
    //Make business logic decision by looking at the action
    if ($dataIn['ajaxPost']['action'] == 'addRating') {
        $dataOut['outcome'] = "Attempted to add rating";
        $dataOut['message'] = "Data available for databasing:";
        $dataOut['callbackID'] = "1";
        foreach ($dataIn['ajaxPost']['allData'] as $dataset)
        {
            $dataOut['message'] .= $dataset['field']
            . " - "
            . $dataset['id']
            . " - "
            . $dataset['value'];
        }
        //Don't forget to validate any inputs - https://www.w3schools.com/php/func_filter_var.asp

        /*Add code to use this data in the database - 
        Retrieving - https://meekro.com/docs/retrieving-data.html, 
        Inserting, updaing and deleting  - https://meekro.com/docs/altering-data.html, 
        Use DB::affectedRows() to check on how many results are returned */
    }

    // submitData("setPreferedStop", "stopsToShow", "");
    //This JS call is send a verb/Noun combo of what to do, and the value from a dropdown called stopsToShow

    if ($dataIn['ajaxPost']['action'] == 'setPreferedStop') {
        $dataOut['outcome'] = "Attempted to remember the prefered bus stop";
        $dataOut['message'] = "Data available for databasing:";
        //print_r($dataIn);
        $stopID = $dataIn['ajaxPost']['allData'][0]['value'];
        $dataOut['message'] .= $stopID;
        $sqlQuery = "UPDATE users SET stop_id = %s WHERE username = %s ";
        DB::query($sqlQuery, $stopID, $_SESSION['username']);
    if (DB::affectedRows()== 1) {
        $dataOut['callbackID'] = "4";
        $dataOut['outcome'] = "stop successfully changed";
        $dataOut['message'] = "<h4 class='text-success'>Prefered stop set to: $stopID</h4><h4>Buses that go through this stop:</h4>";
        $sqlQuery = "Select DISTINCT T.route_id as 'busName' From Stops S, stop_times ST, trips T WHERE S.stop_id = ST.stop_id AND T.trip_id = ST.trip_id AND S.stop_id = %s";
        $buses = DB::query($sqlQuery, $stopID);
        $counter = 0;
        foreach ($buses as $bus)
        {
            //Format the info underneath as a button
            $busName = $bus['busName']; 
            //Add a click handler (Javascript) to run a function called addBus that includes the bus code
            $dataOut['message'] .= "<button id='bus$counter' onclick='setBus(\"$busName\", \"bus$counter\")' class='m-2 btn btn-secondary'>$busName</button>";
            $counter ++;
        }
    }
    else
    {
        $dataOut['callbackID'] = "5";
        $dataOut['outcome'] = "<h1>Problem in updating prefered stop</h1>";
    }
    }

    if ($dataIn['ajaxPost']['action'] == 'searchForStop') {
        $dataOut['callbackID'] = 7;
        $dataOut['message'] = '<h1>Search results:</h1>';
      
        $stopSearchString = $dataIn['ajaxPost']['allData'][0]['value'];
        $stopsData = DB::query(
          'SELECT DISTINCT stop_id, stop_code, stop_name, stop_desc FROM stops WHERE stop_name LIKE %ss OR stop_desc LIKE %ss',
          $stopSearchString,
          $stopSearchString
        );
        $numberOfCurrentRows = DB::affectedRows();
      
        if ($numberOfCurrentRows > 0) {
          // Create new bus markers for the filtered data
          $busMarkers = array();
          for ($counter = 0; $counter < $numberOfCurrentRows - 1; $counter++) {
            $stopName = trim($stopsData[$counter]['stop_name'], '"');
            $stopid = $stopsData[$counter]['stop_id'];
      
            $busMarker = L.marker([stopsData[$counter]['stop_lat'], stopsData[$counter]['stop_lon']], {
              icon: busIcon,
            })
              .bindPopup(`${stopName} ${stopid}`)
              .on('click', () => {
                setPreferredStop(stopid);
                modalArea.hide();
              });
      
            $busMarkers[] = $busMarker;
          }
      
          // Return the busMarkers array to the client
          $dataOut['busData'] = $busMarkers;
        }
      }
      
}

echo json_encode($dataOut);
?>
