<?php 
@session_start();
require_once("db.class.php");
DB::$user = 'root';
DB::$password = '';
DB::$dbName = 'cairns';//Change this to a database specific to your assessment item
//DB::debugMode();
DB::$logfile = 'logfile.txt';

$serverName = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "cairns";


$conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);

if (!$conn) {
    die("Connection failed: " . $mysqli_connect_error());
}

function fetchFerryRoutes()
{
// Execute the query
$result = mysqli_query($conn, "SELECT * FROM routes WHERE route_type = '4';");

// Check for errors
if (!$result) {
    echo "Error executing query: " . mysqli_error($conn);
    exit();
}

// Process the results
while ($row = mysqli_fetch_assoc($result)) {
    echo "Route ID: " . $row["route_id"] . "<br>";
    echo "Route Name: " . $row["route_long_name"] . "<br>";
    echo "Route Type: " . $row["route_type"] . "<br>";
}
}

// Close the connection
mysqli_close($conn);


function permissionsChecker($usertype, $bump)
{
        if (!isset($_SESSION['username']))
    {
        redirect("login.php");
    }
    else
    {
        if ($_SESSION['usertype'] != $usertype) {
            redirect($bump);
        } 
    }
}

function signUpUser($username,$password, $usertype)
{
    DB::query("Select username from users where username = %s", $username);
    $numberOfCurrentRows = DB::affectedRows();
    if ($numberOfCurrentRows > 0)
    {
        return "There has been a problem with this username";
    }
    else
    {
        $hash = password_hash($password, PASSWORD_ARGON2I);
        DB::query("INSERT INTO users (username,password,type) VALUES (%s, '$hash', %s)", $username, $usertype);
        $numberOfNewRows = DB::affectedRows();
        if ($numberOfNewRows == 1) {
            return "Account added";
        } else {
            return "There has been a problem provisioning your account";
        }
    }   
}

function checkLogin($username, $password)
{
    $result = DB::queryFirstRow("SELECT * FROM users WHERE username = %s", $username); //Add extra details you might want to use in your pages ie type, year level
    if (DB::affectedRows() > 0)
    {
        if (password_verify($password, $result['password']))//true - login them in
        {
            $_SESSION['username'] = $username;
            $_SESSION['usertype'] = $result['type'];
            return true;

        }
        else //false - don't log them in
        {
            return false;

        }
    }
}

function redirect($pageName)
{
    $host  = $_SERVER['HTTP_HOST'];
    $uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
    //Change this to redirect your user to a particular page after they are logged out.
    $extra = $pageName;
    header("Location: http://$host$uri/$extra");
    exit;
}

function generateRouteLines($stopID)
{
$result = DB::query("Select distinct shape_id FROM trips WHERE trip_id in (Select distinct trip_id FROM stop_times Where stop_id = %s)",$stopID );
$shapeIDs = "";
foreach ($result as $singleResult)
{
    $shapeIDs .= '"' . rtrim($singleResult['shape_id']) . '",';
}
$shapeIDs = rtrim($shapeIDs, ",");
$individualShapes = DB::query("SELECT shape_id, shape_pt_sequence, shape_pt_lat, shape_pt_lon from shapes where shape_id in ($shapeIDs) order by 1, 2");
$output = "";
$counter = 0;
$lastshapeid = 0;
$firstLon = 0;
$firstLat = 0;
echo "var routeLines = new Array();";
foreach ($individualShapes as $point)
{
        $output .= "[ ";
        $output .= floatval($point['shape_pt_lat']) + ($counter * .000007);
        $output .= ", ";
        $output .= floatval($point['shape_pt_lon']) + ($counter * .000007);
        $output .= " ], ";
        if ($lastshapeid != $point['shape_id'] && $lastshapeid != 0)
        {  
            $output .= rtrim($output, ',');
            echo "routeLines[$counter] = [$output];\n";
            $counter ++;
            $output = "";
        }
        $lastshapeid = $point['shape_id'];
}
}

?>