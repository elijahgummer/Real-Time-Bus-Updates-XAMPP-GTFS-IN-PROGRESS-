<!DOCTYPE html>
<html>
<head>
  <title>Search Results</title>
</head>
<body>
  <?php
  $start = $_GET["start"];
  $end = $_GET["end"];

  // make a database query to find all buses that go from the start location to the end location
  // this code assumes that you have a database table called "buses" with columns for start location and end location
  // replace the database connection details with your own
  $conn = new mysqli("localhost", "root", "", "cairns");
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  $sql = "SELECT * FROM buses WHERE start_location='$start' AND end_location='$end'";
  $result = $conn->query($sql);

  // display the search results
  if ($result->num_rows > 0) {
    echo "<h1>Search Results</h1>";
    echo "<table>";
    echo "<tr><th>Bus Number</th><th>Start Location</th><th>End Location</th></tr>";
    while ($row = $result->fetch_assoc()) {
      echo "<tr><td>".$row["bus_number"]."</td><td>".$row["start_location"]."</td><td>".$row["end_location"]."</td></tr>";
    }
    echo "</table>";
  } else {
    echo "<h1>No buses found</h1>";
  }
  $conn->close();
  ?>
</body>
</html>
