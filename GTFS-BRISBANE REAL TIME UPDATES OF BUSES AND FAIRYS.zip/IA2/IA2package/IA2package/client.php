<?php
require_once("helperFunctions.php");
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <!----===== Boxicons CSS ===== -->
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>

        <!-- ===== Iconscout CSS ===== -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" integrity="sha512-1sCRPdkRXhBV2PBLUdRb4tMg1w2YPf37qatUFeS7zlBy7jJI8Lf4VHwWfZZfpXtYSLy85pkm9GaYVYMfw5BC1A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <!----======== CSS ======== -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
    
    
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.2/dist/leaflet.css"
    integrity="sha256-sA+zWATbFveLLNqWO2gtiw3HL/lh1giY/Inf1BJ0z14="
    crossorigin=""/>
    <script src="https://unpkg.com/leaflet@1.9.2/dist/leaflet.js"
    integrity="sha256-o9N1jGDZrf5tS+Ft4gbIK7mYMipq9lqpVJ91xHSyKhg="
    crossorigin=""></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/pbf@3.2.1/dist/pbf.js"></script>
    <script src="https://unpkg.com/gtfs-realtime-pbf-js-module@1.0.0/gtfs-realtime.browser.proto.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet.markercluster/1.5.1/MarkerCluster.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet.markercluster/1.5.1/MarkerCluster.Default.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet.markercluster/1.5.1/leaflet.markercluster.js"></script>

    <link rel="stylesheet" href="animation.css">
    <link rel="stylesheet" href="main.css">
    <script src="common.js"></script>
    <script src="client.js"></script>
    <script><?php generateRouteLines("1882"); ?></script>
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
</head>
<body>
<header>
<nav>
    <ul>
        <li><a href="#"><i class="fa fa-home fa-lg"></i>Home</a></li>
        <li><a href="#"><i class="fa fa-envelope fa-lg"></i>Messages</a></li>
        <li><a href="#"><i class="fa fa-bell fa-lg"></i>Notifications</a></li>
        <?php
            if (isset($_SESSION["userName"])) {
                echo "";
            }
            else{
                echo "<li><a href='admin.php'><i class='uil uil-airplay'></i>Admin Page</a></li>";
            }

        ?>
    </ul>
    <form class="search-form">
        <input type="text" placeholder="Search...">
        <button type="submit"><i class="fa fa-search"></i></button>
    </form>
    <?php
    if (isset($_SESSION["userName"])) {
        echo "<div class='logged-in'><a href='#'><button>Logged In</button></a></div>";
    }
    else{
        echo "<div class='logged-in'><a href='loginPage.php'><button>Log In</button></a></div>";
    }
    ?>
    <?php
    if (isset($_SESSION["userName"])) {
        ?>
        <div class="profile">
        <a href="#">
        <i class="fas fa-user"></i>
        <i class="fas fa-chevron-down"></i>
        </a>
        <div class="dropdown">
            <a class="dropBox" href="#"><i class="uil uil-user"></i>My Profile</a>
        </i><a class="dropBox" href='#' data-bs-toggle="modal" data-bs-target="#logoutModal"><i class="uil uil-sign-out-alt"></i>Logout</a>
        </div>
        <!---modal for the logout to make sure users acutally want to log out-->
        <div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="modalAreaLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalAreaLabel"><i class="uil uil-signout"></i>Log Out</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div id="modalAreaBody" class="modal-body"><i class="uil uil-exclamation-circle"></i>

                <p>Are You Sure You Want To Log Out?</p>
            </div>
            <div id="modalAreaFooter" class="modal-footer">


                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <a href='logout.inc.php'><button type="button" class="btn btn-danger">Log Out</button></a>
            </div>
            </div>
        </div>
    </div>
    </div>
    <?php     
            }
        ?>
    </nav>
</header>
</div>
    <div class="modal fade" id="modalArea" tabindex="-1" aria-labelledby="modalAreaLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalAreaLabel">Modal title</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div id="modalAreaBody" class="modal-body">
                ...
            </div>
            <div id="modalAreaFooter" class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
            </div>
            </div>
        </div>
    </div>
    <!---Button to login and logout and show ofcanvas and modals-->
    <p>
        <?php
        if (!empty($_SESSION['userName'])) {
        ?>
                <button class="btn btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">
                    Show OffCanvas
                </button>


                
                <button class="btn btn-primary" type="button"  data-bs-toggle="modal" data-bs-target="#modalArea">
                    Show Modal
                </button>
            </p>
        <?php
        }
        ?>
    <div class="alerts"></div>
    <div id="map">
        <div style="margin-top:275px" class="d-flex justify-content-center">
            <div class="spinner-border" role="status">
                <span class="visually-hidden">Loading your map...</span>
            </div>
        </div>
    </div>

    <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
        <div class="offcanvas-header">
            <h5 id="offcanvasRightLabel">Offcanvas right</h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <?php
            //Functionality to display a list of stops in a drop down widget
            // SQL: SELECT DISTINCT stop_id, stop_code, stop_name, stop_desc FROM stops
            echo "<div class='form-group'><label for='stopsToShow'>Select a stop to focus on:</label>";
            echo "<select class='form-control' id='stopsToShow' onchange='setPreferedStop()'>";
            $stopsData = DB::query("SELECT DISTINCT stop_id, stop_code, stop_name, stop_desc FROM stops");
            $numberOfCurrentRows = DB::affectedRows();
            if ($numberOfCurrentRows > 0)
            {
                for ($counter = 0; $counter < $numberOfCurrentRows - 1; $counter++) {
                    $stopName = trim($stopsData[$counter]['stop_name'], '"');
                    $stopCode = $stopsData[$counter]['stop_code'];
                    echo "<option value='$stopCode'>$stopName $stopCode</option>";
                }
            }
            echo "<option>All</option>";
            echo "</select></div>";
            echo "<div id='stopFeedback'></div>";

            ?>
            <h3>Type bus stop details to see suggestions</h3>
            <input type="text" id="textStopSearch" onchange="findSuggestedStops()">
            <div id="suggestions">

            </div>
        </div>
    </div>

            <?php
                if (isset($_SESSION["userName"])) {
                    
                    ?>
                    <div class="alert hide">
                    <span class="fas fa-check-circle"></span>
                    <div class="msg">
                    <?php echo "<p>Hello there " . $_SESSION["userName"] . "</p>";?>
                    </div>
                    <div class="close-btn">
                    <span class="fas fa-times"></span>
                    </div>
                    </div>
                    <script>
                    $('.alert').addClass("show");
                    $('.alert').removeClass("hide");
                    $('.alert').addClass("showAlert");
                    setTimeout(function(){
                    $('.alert').removeClass("show");
                    $('.alert').addClass("hide");
                    },5000);
                    </script>
                    <?php
                }
                    ?>
            

        <script>
            $('.close-btn').click(function(){
            $('.alert').removeClass("show");
            $('.alert').addClass("hide");
            });
        </script>

        <script>
            const profile = document.querySelector('.profile');
            const dropdown = document.querySelector('.dropdown');

            profile.addEventListener('click', () => {
            dropdown.classList.toggle('show');
            });

            window.addEventListener('click', (event) => {
            if (!event.target.matches('.profile') && !event.target.matches('.profile *')) {
                dropdown.classList.remove('show');
            }
            });
        </script>
        <script>    
        // Define an array of possible alerts
        var alerts = ["Bus Route 22 is experiencing delays due to heavy traffic. Please allow extra time for your journey.", "Ferry Service to Staten Island is temporarily suspended due to adverse weather conditions. We apologize for the inconvenience.", "Bus Route 10 is now operating on a diversion due to a road closure. Please check the website for more information", "Ferry Service to Ellis Island is currently running with reduced frequency due to maintenance works. Please plan your journey accordingly.", "Bus Route 14 will experience minor delays during peak hours due to scheduled roadworks. We appreciate your patience."];

        // Define a function to generate a random alert
        function generateRandomAlert() {
            var randomIndex = Math.floor(Math.random() * alerts.length);
            var alertBox = document.querySelector('.alerts');
            alertBox.textContent = alerts[randomIndex];
            alertBox.classList.add('show');
            setTimeout(function() {
            alertBox.classList.remove('show');
            }, 10000);
        }

        // Set an interval to call the function every 20 seconds
        setInterval(generateRandomAlert, 20000);
        </script>


</body>

<html>
