<?php
session_start();
//Remove these to stop automatic login of the user test
$_SESSION['username'] = "test";
$_SESSION['usertype'] = "test";
?>
<h1>Login placeholder</h1>
<p><a href="client.php">Client Page</a></p>