<?php

require 'Includes/dbh.inc.php';
session_start();


if(isset($_POST['delete_student']))
{
    $users_id = mysqli_real_escape_string($conn, $_POST['delete_student']);

    $query = "DELETE FROM users WHERE UserID ='$users_id' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Student Deleted Successfully";
        header("Location: admin.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Deleted";
        header("Location: admin.php");
        exit(0);
    }
}

if(isset($_POST['update_student']))
{
    $user_id = mysqli_real_escape_string($conn, $_POST['UserID']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $UserType = mysqli_real_escape_string($conn, $_POST['UserType']);


    $query = "UPDATE users SET username ='$username', email ='$email', UserType ='$UserType' WHERE UserID ='$user_id' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Student Updated Successfully";
        header("Location: admin.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Updated";
        header("Location: admin.php");
        exit(0);
    }

}


if(isset($_POST['save_user']))
{
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $Password = mysqli_real_escape_string($conn, $_POST['password']);
    $hashedPwd = password_hash($Password, PASSWORD_DEFAULT);
    $query = "INSERT INTO users (username, email, password) VALUES ('$username','$email','$hashedPwd')";

    $query_run = mysqli_query($conn, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Student Created Successfully";
        header("Location: admin.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Created";
        header("Location: admin.php");
        exit(0);
    }
}

?>
