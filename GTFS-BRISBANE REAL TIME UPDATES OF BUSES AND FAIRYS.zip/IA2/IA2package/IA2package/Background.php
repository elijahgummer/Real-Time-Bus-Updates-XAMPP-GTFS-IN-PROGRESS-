<head>
<link rel="stylesheet" href="back.css">
<canvas id="canvas"></canvas>
<script src='background.js'></script>
<head> 