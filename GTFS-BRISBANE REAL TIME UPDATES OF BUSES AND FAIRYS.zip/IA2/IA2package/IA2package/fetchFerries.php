<?php
session_start();
$serverName = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "cairns";


$conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);

if (!$conn) {
    die("Connection failed: " . $mysqli_connect_error());
}


// Execute the query
$result = mysqli_query($conn, "SELECT * FROM routes WHERE route_type = '4';");

// Check for errors
if (!$result) {
    echo "Error executing query: " . mysqli_error($conn);
    exit();
}

// Convert the result set into an array
$ferries = array();
while ($row = mysqli_fetch_assoc($result)) {
    $ferries[] = $row;
}

// Process the results
while ($row = mysqli_fetch_assoc($result)) {
    echo "Route ID: " . $row["route_id"] . "<br>";
    echo "Route Name: " . $row["route_long_name"] . "<br>";
    echo "Route Type: " . $row["route_type"] . "<br>";
}

// Close the connection
mysqli_close($conn);
?>