<?php
session_start();
?>
<!DOCTYPE html>
    <html>
    <head>
    <title>Login and Registration</title>

    <!-- ===== Iconscout CSS ===== -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" integrity="sha512-1sCRPdkRXhBV2PBLUdRb4tMg1w2YPf37qatUFeS7zlBy7jJI8Lf4VHwWfZZfpXtYSLy85pkm9GaYVYMfw5BC1A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-------CSS--------->
     <link rel="stylesheet" href="css/Login.css">
    </head>
     <body> 
     <button class="button4">Privacy Policy</button>
        <div class="main_div">
            <div class="form">
                <!---Register Form------>
                <form action="Includes/signup.inc.php" class="register-form" method="post">

                    <div class="image-container">
                    <img src="logoTransit.png">
                    </div>
                    <div class="title">Registration</div>

                    <span class="sub">Make Your Account</span>

                    <div class="input_box">
                    <input type="text" name="username" placeholder=" Enter Username"/>
                    <div class="icon"><i class="fas fa-user"></i></div>
                    </div>

                    <div class="input_box">
                        <input type="text" name="email" placeholder="Enter Email" required>
                        <div class="icon"><i class="fas fa-envelope"></i></div>
                    </div>

                    <div class="input_box">
                    <input type="password" name="pwd" class="password" placeholder="Enter Password" required>
                    <div class="icon"><i class="fas fa-lock"></i></div>
                    </div>

                    <div class="input_box">
                    <input type="password" name="pwdrepeat" class="password" placeholder="Repeat Password..." required>
                    <div class="icon"><i class="fas fa-lock"></i></div>
                    <i class="uil uil-eye-slash showHidePw"></i>
                    </div> 

                    <div class="input_box button">
                        <input type="submit" name="submit">
                    </div>
                    <div class="sign_up">
                    <span class="sign_up">Already Registered?<a href="#">Login</a></span>
                    </div>
                </form>

                <!------------LOGIN FORM ------------>
                <form action="Includes/login.inc.php" class="login-form" method="post">          
                    <div class="image-container">
                    <img src="logoTransit.png">
                    </div>
                    <div class="title">Login Form</div>
                    <span class="sub">Sign in To your account</span>
                    <form action="#">
                    <div class="input_box">
                        <input type="text" name="username" placeholder="Email or Username" required>
                        <div class="icon"><i class="fas fa-user"></i></div>
                    </div>
                    <div class="input_box">
                        <input type="password" name="pwd" class="password" placeholder="Password" required>
                        <div class="icon"><i class="fas fa-lock"></i></div>
                        <i class="uil uil-eye-slash showHidePw"></i>
                    </div>
                    <div class="option_div">
                        <div class="check_box">
                        <input type="checkbox">
                        <span>Remember me</span>
                        </div>
                        <div class="forget_div">
                        <a href="#">Forgot password?</a>
                        </div>
                    </div>
                    <div class="input_box button">
                        <input type="submit" name="submit" value="Login">
                    </div>
                    <div class="sign_up">
                        Not a member? <a href="#">Signup now</a>
                    </div>
                    </form>
                    <?php
                    if (isset($_GET["error"])) {
                        if ($_GET["error"] == "emptyinput") {
                            echo "<p>Fill in all fields!</p>";
                        }
                        else if ($_GET["error"] == "invalidemail") {
                            echo "<p >Choose a proper email</p>";
                        }
                        else if ($_GET["error"] == "stmtfailed") {
                            echo "<p>Somthing went wrong, try again!</p>";
                        }
                        else if ($_GET["error"] == "none") {
                            echo "<p>you have signed up!</p>";
                        }
                        else if ($_GET["error"] == "wronglogin") {
                            echo "<p>incorrect login information!</p>";
                        }
                        else if ($_GET["error"] == "usernametaken") {
                            echo "<p>Username Already taken!</p>";
                        }
                        else if ($_GET["error"] == "invaliduid") {
                            echo "<p>Choose a proper username</p>";
                        }
                        else if ($_GET["error"] == "passwordsdontmatch") {
                            echo "<p>Passwords doesn't match!</p>";
                        }
                    }
                    ?>
                </div>
                <script>
                    const pwShowHide = document.querySelectorAll(".showHidePw"),
                    pwFields = document.querySelectorAll(".password"),
                    signUp = document.querySelector(".signup-link"),
                    login = document.querySelector(".login-link");

                    //   js code to show/hide password and change icon
                    pwShowHide.forEach(eyeIcon =>{
                        eyeIcon.addEventListener("click", ()=>{
                            pwFields.forEach(pwField =>{
                                if(pwField.type ==="password"){
                                    pwField.type = "text";

                                    pwShowHide.forEach(icon =>{
                                        icon.classList.replace("uil-eye-slash", "uil-eye");
                                    })
                                }else{
                                    pwField.type = "password";

                                    pwShowHide.forEach(icon =>{
                                        icon.classList.replace("uil-eye", "uil-eye-slash");
                                    })
                                }
                            }) 
                        })
                    })

                </script>
                </form>
            </div>
        </div>
    
        <script src='https://code.jquery.com/jquery-3.2.1.min.js'></script>

        <script> 
            $('.sign_up a').click(function(){
            $('form').animate({height: "toggle", opacity: "toggle"}, "slow");
        });</script>
        <script> 
            $('button a').click(function(){
            $('').animate({height: "toggle", opacity: "toggle"}, "slow");
        });</script>
     </body>
    </html>


